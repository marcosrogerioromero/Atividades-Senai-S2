var botao = document.getElementById('botaoclicar') //Pegar o elemento pelo id

botao.onclick = function(){//Ao clicar no botão executa a função
    alert('Voce clicou no botão') //Da um alerta com uma mensagem de sua escolha dentro dos parenteses
}

